$("#mobile").intlTelInput({

    autoPlaceholder: true,
    onlyCountries: ["nz", "ar", "br", "cl", "es", "jp", "uy", "us"],
    preferredCountries: ["br", "jp"],
    allowDropdown: true,
    initialCountry: "auto",
    utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/12.0.3/js/utils.js",
    geoIpLookup: function (callback) {
        $.get('https://ipinfo.io', function () { }, "jsonp").always(function (resp) {
            var countryCode = (resp && resp.country) ? resp.country : "";
            callback(countryCode);
        });
    }


});