"use strict";

let check_language = localStorage.getItem('language');


// Checking if the selected language is english or spanish
if (check_language == 'english') {
    $("#country-select-test option[value=english]").attr('selected', 'selected');
    fetch('./doctor.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file
        let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = mymenu;
        // About heading
        let contentdoctor = xmlDoc.getElementsByTagName('DoctorPage')[0].innerHTML;
        document.getElementById('doctor-content-div').innerHTML = contentdoctor;


    });

}
else if (check_language == 'spanish') {
    $("#country-select-test option[value=spanish]").attr('selected', 'selected');
    fetch('./doctorspanish.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file

        // The main menu
        let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = mymenu;

        // About heading
        let contentdoctor = xmlDoc.getElementsByTagName('DoctorPage')[0].innerHTML;
        document.getElementById('doctor-content-div').innerHTML = contentdoctor;


    });

}
else if (check_language == 'german') {
    $("#country-select-test option[value=german]").attr('selected', 'selected');
    fetch('./doctorgerman.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file

        // The main menu
        let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = mymenu;

        // About heading
        let contentdoctor = xmlDoc.getElementsByTagName('DoctorPage')[0].innerHTML;
        document.getElementById('doctor-content-div').innerHTML = contentdoctor;


    });

}




// Fetching data when the language button is changed 

$(document.body).on("change", "#country-select-test", function () {

    localStorage.setItem('language', this.value);

    let language = this.value;

    if (language == 'english') {

        /* About us content  for home page */
        fetch('./doctor.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // Fetching about heading from xml file and adding it into html file
            let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = mymenu;

            let contentdoctor = xmlDoc.getElementsByTagName('DoctorPage')[0].innerHTML;
            document.getElementById('doctor-content-div').innerHTML = contentdoctor;




        });
    }
    else if (language == 'spanish') {
        /* About us content  for home page */
        fetch('./doctorspanish.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // Fetching about heading from xml file and adding it into html file
            let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = mymenu;

            let contentdoctor = xmlDoc.getElementsByTagName('DoctorPage')[0].innerHTML;
            document.getElementById('doctor-content-div').innerHTML = contentdoctor;
        });
    }
    else if (language == 'german') {
        /* About us content  for home page */
        fetch('./doctorgerman.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // Fetching about heading from xml file and adding it into html file
            let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = mymenu;

            let contentdoctor = xmlDoc.getElementsByTagName('DoctorPage')[0].innerHTML;
            document.getElementById('doctor-content-div').innerHTML = contentdoctor;
        });
    }


});



