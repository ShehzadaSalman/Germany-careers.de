"use strict";
let check_language = localStorage.getItem('language');


if (check_language == 'english') {
    $("#country-select-test option[value=english]").attr('selected', 'selected');
    fetch('./Itprofessional.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file
        // Menu bar
        let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = mymenu;

        // About heading
        let contentit = xmlDoc.getElementsByTagName('ITPage')[0].innerHTML;
        document.getElementById('it-content-div').innerHTML = contentit;
    });
}
else if (check_language == 'spanish') {
    $("#country-select-test option[value=spanish]").attr('selected', 'selected');
    fetch('./Itprofessionalspanish.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file
        let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = mymenu;

        // About heading
        let contentit = xmlDoc.getElementsByTagName('ITPage')[0].innerHTML;
        document.getElementById('it-content-div').innerHTML = contentit;
    });
}
else if (check_language == 'german') {
    $("#country-select-test option[value=german]").attr('selected', 'selected');
    fetch('./Itprofessionalgerman.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file
        let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = mymenu;

        // About heading
        let contentit = xmlDoc.getElementsByTagName('ITPage')[0].innerHTML;
        document.getElementById('it-content-div').innerHTML = contentit;
    });
}




// Fetching data when the language button is changed 

$(document.body).on("change", "#country-select-test", function () {

    localStorage.setItem('language', this.value);

    let language = this.value;

    if (language == 'english') {

        /* About us content  for home page */
        fetch('./Itprofessional.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = mymenu;

            // Fetching content from nurse xml
            let contentit = xmlDoc.getElementsByTagName('ITPage')[0].innerHTML;
            document.getElementById('it-content-div').innerHTML = contentit;
        });
    }
    else if (language == 'spanish') {
        /* About us content  for home page */
        fetch('./Itprofessionalspanish.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // Fetching about heading from xml file and adding it into html file
            let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = mymenu;


            let contentit = xmlDoc.getElementsByTagName('ITPage')[0].innerHTML;
            document.getElementById('it-content-div').innerHTML = contentit;
        });
    }
    else if (language == 'german') {
        /* About us content  for home page */
        fetch('./Itprofessionalgerman.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // Fetching about heading from xml file and adding it into html file
            let mymenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = mymenu;


            let contentit = xmlDoc.getElementsByTagName('ITPage')[0].innerHTML;
            document.getElementById('it-content-div').innerHTML = contentit;
        });
    }
});

