
"use strict";



function mystorage() {
    if (localStorage.getItem('isDefined') == 'once') {
        // This works when the function has been defined already


    } else {

        // This works when the local storage has not been defined yet
        alert('this works when the local variable has not beed defined yet');
        localStorage.setItem('isDefined', 'once');
        localStorage.setItem('language', 'english');

    }


}

mystorage();
// $('$country-select-test').val('spanish');
// Pulling xml value according to the local storage variable
/* About us content  for home page */

let checklanguage = localStorage.getItem('language');


// Bringing English content here
if (checklanguage == 'english') {
    $("#country-select-test option[value=english]").attr('selected', 'selected');

    fetch('./home.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Getting main menu 
        let homemenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = homemenu;

        // About heading
        let Aboutheading = xmlDoc.getElementsByTagName('About-Heading')[0].innerHTML;
        document.getElementById('about-heading').innerHTML = Aboutheading;

        // About Paragraph one
        let AboutOne = xmlDoc.getElementsByTagName('About-paragraphOne')[0].innerHTML;
        document.getElementById('about-paragraph-one').innerHTML = AboutOne;

        // About Paragraph two
        let AboutTwo = xmlDoc.getElementsByTagName('About-paragraphTwo')[0].innerHTML;
        document.getElementById('about-paragraph-two').innerHTML = AboutTwo;
    });





}

if (checklanguage == 'spanish') {
    $("#country-select-test option[value=spanish]").attr('selected', 'selected');

    fetch('./homespanish.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file
        let homemenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = homemenu;
        // About heading
        let Aboutheading = xmlDoc.getElementsByTagName('About-Heading')[0].innerHTML;
        document.getElementById('about-heading').innerHTML = Aboutheading;

        // About Paragraph one
        let AboutOne = xmlDoc.getElementsByTagName('About-paragraphOne')[0].innerHTML;
        document.getElementById('about-paragraph-one').innerHTML = AboutOne;

        // About Paragraph two
        let AboutTwo = xmlDoc.getElementsByTagName('About-paragraphTwo')[0].innerHTML;
        document.getElementById('about-paragraph-two').innerHTML = AboutTwo;
    });
}


if (checklanguage == 'german') {
    $("#country-select-test option[value=german]").attr('selected', 'selected');

    fetch('./homegerman.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file
        let homemenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = homemenu;
        // About heading
        let Aboutheading = xmlDoc.getElementsByTagName('About-Heading')[0].innerHTML;
        document.getElementById('about-heading').innerHTML = Aboutheading;

        // About Paragraph one
        let AboutOne = xmlDoc.getElementsByTagName('About-paragraphOne')[0].innerHTML;
        document.getElementById('about-paragraph-one').innerHTML = AboutOne;

        // About Paragraph two
        let AboutTwo = xmlDoc.getElementsByTagName('About-paragraphTwo')[0].innerHTML;
        document.getElementById('about-paragraph-two').innerHTML = AboutTwo;
    });



}

// Fetching the data and changing stuff when the change occurs

$(document.body).on("change", "#country-select-test", function () {

    localStorage.setItem('language', this.value);

    let newlanguage = localStorage.getItem('language');


    if (newlanguage == 'english') {

        /* About us content  for home page */
        fetch('./home.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // Fetching about heading from xml file and adding it into html file
            let homemenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = homemenu;
            // About heading
            let Aboutheading = xmlDoc.getElementsByTagName('About-Heading')[0].innerHTML;
            document.getElementById('about-heading').innerHTML = Aboutheading;

            // About Paragraph one
            let AboutOne = xmlDoc.getElementsByTagName('About-paragraphOne')[0].innerHTML;
            document.getElementById('about-paragraph-one').innerHTML = AboutOne;

            // About Paragraph two
            let AboutTwo = xmlDoc.getElementsByTagName('About-paragraphTwo')[0].innerHTML;
            document.getElementById('about-paragraph-two').innerHTML = AboutTwo;
        });
    }
    else if (newlanguage == 'spanish') {

        /* About us content  for home page */
        fetch('./homespanish.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // Fetching about heading from xml file and adding it into html file
            let homemenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = homemenu;
            // About heading
            let Aboutheading = xmlDoc.getElementsByTagName('About-Heading')[0].innerHTML;
            document.getElementById('about-heading').innerHTML = Aboutheading;

            // About Paragraph one
            let AboutOne = xmlDoc.getElementsByTagName('About-paragraphOne')[0].innerHTML;
            document.getElementById('about-paragraph-one').innerHTML = AboutOne;

            // About Paragraph two
            let AboutTwo = xmlDoc.getElementsByTagName('About-paragraphTwo')[0].innerHTML;
            document.getElementById('about-paragraph-two').innerHTML = AboutTwo;
        });


    }

    else if (newlanguage == 'german') {

        /* About us content  for home page */
        fetch('./homegerman.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // Fetching about heading from xml file and adding it into html file
            let homemenu = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = homemenu;
            // About heading
            let Aboutheading = xmlDoc.getElementsByTagName('About-Heading')[0].innerHTML;
            document.getElementById('about-heading').innerHTML = Aboutheading;

            // About Paragraph one
            let AboutOne = xmlDoc.getElementsByTagName('About-paragraphOne')[0].innerHTML;
            document.getElementById('about-paragraph-one').innerHTML = AboutOne;

            // About Paragraph two
            let AboutTwo = xmlDoc.getElementsByTagName('About-paragraphTwo')[0].innerHTML;
            document.getElementById('about-paragraph-two').innerHTML = AboutTwo;
        });


    }


});














