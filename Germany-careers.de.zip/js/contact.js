"use strict";

// Checking the value of global variables and calling xml files accordingly

let check_language = localStorage.getItem('language');

if (check_language == 'english') {
    $("#country-select-test option[value=english]").attr('selected', 'selected');

    /* Content fetching for Technician Page */
    fetch('./contact.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file

        // Getting Menu
        let contenttechnician = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = contenttechnician;


    });

}

else if (check_language == 'spanish') {
    $("#country-select-test option[value=spanish]").attr('selected', 'selected');

    /* Content fetching for Technician Page */
    fetch('./contactspanish.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file

        // About heading
        let contenttechnician = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = contenttechnician;
    });

}

else if (check_language == 'german') {
    $("#country-select-test option[value=german]").attr('selected', 'selected');

    /* Content fetching for Technician Page */
    fetch('./contactgerman.xml').then(function (resp) {
        return resp.text();
    }).then(function (data) {
        let parser = new DOMParser();
        // data from the xml page 
        let xmlDoc = parser.parseFromString(data, 'text/xml');

        // Fetching about heading from xml file and adding it into html file

        // About heading
        let contenttechnician = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
        document.getElementById('main-menu').innerHTML = contenttechnician;
    });

}

// Fetching data when the language button is changed 

$(document.body).on("change", "#country-select-test", function () {

    localStorage.setItem('language', this.value);

    let language = this.value;
    if (language == 'english') {

        /* About us content  for home page */
        fetch('./contact.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');

            // F
            let contenttechnician = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = contenttechnician;



        });
    }
    else if (language == 'spanish') {
        /* About us content  for home page */
        fetch('./contactspanish.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');



            // Fetching and adding content to page
            let contenttechnician = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = contenttechnician;


        });


    }
    else if (language == 'german') {
        /* About us content  for home page */
        fetch('./contactgerman.xml').then(function (resp) {
            return resp.text();
        }).then(function (data) {
            let parser = new DOMParser();
            // data from the xml page 
            let xmlDoc = parser.parseFromString(data, 'text/xml');



            // Fetching and adding content to page
            let contenttechnician = xmlDoc.getElementsByTagName('menu')[0].innerHTML;
            document.getElementById('main-menu').innerHTML = contenttechnician;


        });


    }


});

