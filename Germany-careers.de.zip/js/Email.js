$("#contact_submit").click(function() {


var data = {

    name: $("#name").val(),
    phone: $("#phone").val(),
    email: $("#email").val(),
    subject: $("#subject").val(),
    Attachment: $("#validatedCustomFile").val(),
    message: $("#message").val()
};
$.ajax({
    type: "POST",
    url: "mail.php",
    data: data,
    success: function(response){
       alert(response);
    }
});

});